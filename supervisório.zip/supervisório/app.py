import time  # Importa o módulo time para controlar intervalos de tempo
import threading  # Importa o módulo threading para criar e gerenciar threads
import subprocess  # Importa o módulo subprocess para executar comandos externos
import os  # Importa o módulo os para interagir com o sistema operacional
# Importa funções do Flask para criar um servidor web
from flask import Flask, render_template, request, jsonify
# Importa SocketIO para adicionar suporte a WebSockets no Flask
from flask_socketio import SocketIO, emit
# Importa o módulo que gerencia o banco de dados de configurações
import banco_de_dados_configuracoes
# Importa o módulo que gerencia o banco de dados de experimentos
import banco_de_dados_experimentos
# Importa função para obter dados do banco de dados
from escolha_dash import get_data_from_db

app = Flask(__name__)  # Cria uma instância do Flask


# Define uma chave secreta para o SocketIO
app.config['SECRET_KEY'] = 'your_secret_key_here'
socketio = SocketIO(app)  # Inicializa o SocketIO com o app Flask


# Define a rota inicial
@app.route('/')
def index():
    nome_banco_de_dados = 'dados_experimentos.db'
    nome_tabela = '"06-07-2024"'

    # Verifica se o banco de dados de experimentos existe, se não, cria e inicializa
    if not os.path.exists('dados_experimentos.db'):
        banco_de_dados_experimentos.criar_banco_dados(
            nome_banco_de_dados, nome_tabela)
        banco_de_dados_experimentos.inserir_banco_dados(
            nome_banco_de_dados, nome_tabela, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

    # Verifica se o banco de dados de configurações existe, se não, cria e inicializa
    if not os.path.exists('dados_planta.db'):
        banco_de_dados_configuracoes.criar_banco_dados()
        banco_de_dados_configuracoes.inserir_banco_dados(
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'True')

    # Consulta os últimos dados inseridos no banco de dados de experimentos e configurações
    dados_experimentos = banco_de_dados_experimentos.consultar_ultimo_id_banco_dados(
        nome_banco_de_dados, nome_tabela)
    dados_configuracoes = banco_de_dados_configuracoes.consultar_ultimo_id_banco_dados()

    # Renderiza o template 'index.html' com os dados dos experimentos e configurações
    return render_template('index.html', dados_experimentos=dados_experimentos, dados_configuracoes=dados_configuracoes)

# Define a rota para os dados


@app.route('/dados')
def dados():
    nome_banco_de_dados = 'dados_experimentos.db'
    nome_tabela = '"06-07-2024"'

    # Consulta os últimos dados inseridos no banco de dados de experimentos e configurações
    dados_experimentos = banco_de_dados_experimentos.consultar_ultimo_id_banco_dados(
        nome_banco_de_dados, nome_tabela)
    dados_configuracoes = banco_de_dados_configuracoes.consultar_ultimo_id_banco_dados()

    # Retorna os dados em formato JSON
    return jsonify({
        'dados_experimentos': dados_experimentos,
        'dados_configuracoes': dados_configuracoes
    })

# Define a rota para a página de experimentos


@app.route('/experimentos')
def realtime():
    # Renderiza o template 'experimentos.html'
    return render_template('experimentos.html')

# Define a rota para a página sobre


@app.route('/sobre')
def about():
    return render_template('about.html')  # Renderiza o template 'about.html'


# Define a rota para iniciar o Arduino
@app.route('/start_arduino', methods=['GET'])
def start_arduino():
    try:
        arduino_path = r'C:\Users\usuario\AppData\Local\Programs\Arduino IDE\Arduino IDE.exe'

        # Caminhos completos dos arquivos // REFAZER PARA CADA BOTÃO ARDUINO
        file_paths = [
            r'C:\Users\usuario\Desktop\codigos_arduino\Valvulas_05-03-24.ino',
            r'C:\Users\usuario\Desktop\codigos_arduino\Pesos_19-12-23.ino',
            r'C:\Users\usuario\Desktop\codigos_arduino\CodigoGeral_19-12-23.ino'
        ]

        # Executa o Arduino IDE com os arquivos especificados
        subprocess.Popen([arduino_path] + file_paths)

        # Retorna uma mensagem de sucesso em formato JSON
        return jsonify({"status": "success", "message": "Arduino IDE started with files"})
    except Exception as e:
        # Em caso de erro, retorna a mensagem de erro em formato JSON
        return jsonify({"status": "error", "message": str(e)})


# Define a rota para atualizar os dados
@app.route('/update_data', methods=['POST'])
def update_data():
    data = request.json  # Obtém os dados enviados na requisição POST
    print(data)  # Imprime os dados recebidos (apenas para debug)

    try:
        # Atualiza os dados no banco de dados de configurações com os valores recebidos
        banco_de_dados_configuracoes.atualizar_banco_dados(
            1,
            data['T0_min'], data['T0_max'], data['T1_min'], data['T1_max'],
            data['T2_min'], data['T2_max'], data['T3_min'], data['T3_max'],
            data['P0_inicial'], data['P1_inicial'], data['P2_inicial'], data['P3_inicial'],
            data['Patamar'], data['tempoparafim'], data['Quanto'], data['Muda_sp']
        )

        # Retorna uma mensagem de sucesso em formato JSON
        return jsonify({"status": "success", "message": "Data updated successfully"})
    except Exception as e:
        # Em caso de erro, imprime a mensagem de erro e retorna em formato JSON
        print(f"Erro na atualização dos dados: {e}")
        return jsonify({"status": "error", "message": str(e)})


# Define a rota para o SocketIO
@socketio.on('connect')
def handle_connect():
    # Imprime uma mensagem quando um cliente se conecta
    print('Cliente conectado')
    emit('message', {'data': 'Connected'})  # Emite uma mensagem para o cliente
    # Cria uma thread para enviar dados periodicamente
    thread = threading.Thread(target=send_data)
    thread.start()  # Inicia a thread


# Define a rota para enviar os dados
def send_data():

    nome_banco_de_dados = 'dados_experimentos.db'
    nome_tabela = '"06-07-2024"'

    while True:
        # Consulta os últimos dados do banco de dados de experimentos e configurações
        dados_experimentos = banco_de_dados_experimentos.consultar_ultimo_id_banco_dados(
            nome_banco_de_dados, nome_tabela)
        dados_configuracoes = banco_de_dados_configuracoes.consultar_ultimo_id_banco_dados()

        # Emite os dados para o cliente via WebSocket
        socketio.emit('update_data', {
            'dados_experimentos': dados_experimentos,
            'dados_configuracoes': dados_configuracoes
        })
        time.sleep(5)  # Aguarda 5 segundos antes de enviar os dados novamente


# Define a rota para buscar dados específicos com base na data
@app.route('/data')
def data():
    # Obtém a data dos parâmetros da requisição
    date = request.args.get('date')
    if not date:
        # Retorna erro se a data não for fornecida
        return jsonify({'error': 'Date parameter is required'}), 400
    # Obtém os dados do banco de dados para a data fornecida
    data = get_data_from_db(date)
    if data is None:
        # Retorna erro se não houver dados para a data
        return jsonify({'error': 'No data for this date'}), 404
    return jsonify(data)  # Retorna os dados em formato JSON

# Define uma rota adicional para a página de experimentos


@app.route('/experi')
def experi():
    # Renderiza o template 'experimentos.html'
    return render_template('experimentos.html')


# Inicia o aplicativo Flask
if __name__ == '__main__':
    # Cria o banco de dados de configurações se ainda não existir
    banco_de_dados_configuracoes.criar_banco_dados()
    # Executa o servidor com SocketIO e Flask, com debug ativo
    socketio.run(app, debug=True)
