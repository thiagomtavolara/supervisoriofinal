import banco_de_dados_experimentos

# Definição das variáveis globais
global t3_sp
global Tempo_final
global tempoparafim
global medidas
global primeiravez0
global primeiravez1
global primeiravez2
global primeiravez3
global novoprimeiravez
global nome
global listatempo
global P0
global P1
global P2
global P3
global T0
global T1
global T2
global T3
global tb1
global tb2
global tb3
global patamar

# Inicialização das variáveis
medidas = 10  # Exemplo: Defina o valor de 'medidas' conforme necessário

# Criação de listas com o tamanho definido por 'medidas'
T0 = [0] * medidas
T1 = [0] * medidas
T2 = [0] * medidas
T3 = [0] * medidas
T0_sp = [0] * medidas
T1_sp = [0] * medidas
T2_sp = [0] * medidas
T3_sp = [0] * medidas
P0 = [0] * medidas
P1 = [0] * medidas
P2 = [0] * medidas
P3 = [0] * medidas
J1 = [0] * medidas
listatempo = [0] * medidas

Vaz1 = 1
Vaz2 = 1
Vaz3 = 1

# Definição dos valores das variáveis
T0[medidas-1] = 3
T1[medidas-1] = 1
T2[medidas-1] = 1
T3[medidas-1] = 1
T0_sp[medidas-1] = 1
T1_sp[medidas-1] = 1
T2_sp[medidas-1] = 1
T3_sp[medidas - 1] = 1
P0[medidas-1] = 1
P1[medidas-1] = 1
P2[medidas-1] = 1
P3[medidas-1] = 1
J1[medidas-1] = 1
listatempo[medidas-1] = 1

# Exemplo de uso da função para inserir dados no banco de dados
nome_banco_de_dados = 'dados_experimentos.db'
nome_tabela = '"06-07-2024"'  # Ajuste conforme necessário

banco_de_dados_experimentos.inserir_banco_dados(
    nome_banco_de_dados, nome_tabela,
    T0[medidas-1], T1[medidas-1], T2[medidas-1], T3[medidas-1],
    T0_sp[medidas-1], T1_sp[medidas-1], T2_sp[medidas-1], T3_sp[medidas - 1],
    P0[medidas-1], P1[medidas-1], P2[medidas-1], P3[medidas-1],
    J1[medidas-1], Vaz1, Vaz2, Vaz3, listatempo[medidas-1]
)
