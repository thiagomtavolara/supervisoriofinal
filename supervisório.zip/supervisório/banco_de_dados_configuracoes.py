import sqlite3


# Função para conectar ao banco de dados


def conectar_banco_dados():
    conexao = sqlite3.connect('dados_planta.db')
    return conexao

# Função para ativar cursor ao banco de dados


def cursor_banco_dados(conexao):
    cursor = conexao.cursor()
    return cursor


# Função para criar o banco de dados(se já tiver ele só ignora)


def criar_banco_dados():

    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)

    # Criar uma tabela se não existir
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS "variaveis" (
	"id"	INTEGER ,
	"T0_min"	REAL NOT NULL,
	"T0_max"	REAL NOT NULL,
	"T1_min"	REAL NOT NULL,
	"T1_max"	REAL NOT NULL,
	"T2_min"	REAL NOT NULL,
	"T2_max"	REAL NOT NULL,
	"T3_min"	REAL NOT NULL,
	"T3_max"	REAL NOT NULL,
	"P0_inicial"	REAL NOT NULL,
	"P1_inicial"	REAL NOT NULL,
	"P2_inicial"	REAL NOT NULL,
	"P3_inicial"	REAL NOT NULL,
	"Patamar"	REAL NOT NULL,
	"Tempoparafim"	REAL NOT NULL,
	"Quanto"	REAL NOT NULL,
	"Muda_sp"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
)
    ''')

    conexao.commit()
    conexao.close()


# Função para inserir no banco de dados

def inserir_banco_dados(T0_min, T0_max, T1_min, T1_max, T2_min, T2_max, T3_min, T3_max, 
                        P0_inicial, P1_inicial, P2_inicial, P3_inicial, Patamar, 
                        Tempoparafim, Quanto, Muda_sp):
    print(f"Inserindo dados: {T0_min}, {T0_max}, {T1_min}, {T1_max}, {T2_min}, {T2_max}, {T3_min}, {T3_max}, {P0_inicial}, {P1_inicial}, {P2_inicial}, {P3_inicial}, {Patamar}, {Tempoparafim}, {Quanto}, {Muda_sp}")
    
    try:
        conn = sqlite3.connect('dados_planta.db')
        print("Conexão ao banco de dados estabelecida com sucesso.")
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO variaveis (T0_min, T0_max, T1_min, T1_max, T2_min, T2_max, T3_min, T3_max, 
                                       P0_inicial, P1_inicial, P2_inicial, P3_inicial, Patamar, 
                                       Tempoparafim, Quanto, Muda_sp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (T0_min, T0_max, T1_min, T1_max, T2_min, T2_max, T3_min, T3_max, P0_inicial, P1_inicial, 
              P2_inicial, P3_inicial, Patamar, Tempoparafim, Quanto, Muda_sp))
        
        conn.commit()
        print("Dados inseridos com sucesso.")
    except sqlite3.Error as e:
        print(f"Erro ao inserir dados: {e}")
    finally:
        conn.close()
        print("Conexão ao banco de dados fechada.")



# Função para consultar o ultimo id no banco de dados
def consultar_ultimo_id_banco_dados():
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute(
        'SELECT T0_min, T0_max, T1_min, T1_max, T2_min,T2_max, T3_min, T3_max, P0_inicial, P1_inicial, P2_inicial, P3_inicial, Patamar,Tempoparafim, Quanto, Muda_sp FROM variaveis ORDER BY id DESC LIMIT 1')
    dados = cursor.fetchall()
    cursor.close()
    conexao.commit()
    conexao.close()
    return dados


# Função para obter os ultimos dados de configurações em um array
def consultar_configuracoes():
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute(
        'SELECT * FROM variaveis ORDER BY id DESC LIMIT 1')
    dados = cursor.fetchone()
    cursor.close()
    conexao.close()
    return dados if dados else None



# Função para consultar todos os id no banco de dados


def consultar_todos_id_banco_dados():
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute('SELECT * FROM variaveis')
    dados = cursor.fetchall()
    cursor.close()
    conexao.commit()
    conexao.close()
    return dados


# Função para atualizar no banco de dados

def atualizar_banco_dados(id, T0_min, T0_max, T1_min, T1_max, T2_min, T2_max, T3_min, T3_max, P0_inicial, P1_inicial, P2_inicial, P3_inicial, Patamar, Tempoparafim, Quanto, Muda_sp):
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute(''' 
        UPDATE variaveis 
        SET T0_min = ?, T0_max = ?, T1_min = ?, T1_max = ?, T2_min = ?, T2_max = ?, T3_min = ?, T3_max = ?, P0_inicial = ?, P1_inicial = ?, P2_inicial = ?, P3_inicial = ?, Patamar = ?,Tempoparafim = ?, Quanto = ?, Muda_sp =?
        WHERE id = ? 
    ''', (T0_min, T0_max, T1_min, T1_max, T2_min, T2_max, T3_min, T3_max, P0_inicial, P1_inicial, P2_inicial, P3_inicial, Patamar, Tempoparafim, Quanto, Muda_sp, id))
    conexao.commit()
    cursor.close()
    conexao.close()

# Função para deletar no banco de dados


def deletar_banco_dados(id):
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute('''DELETE FROM variaveis WHERE id = ?''', (id,))
    cursor.execute('''UPDATE variaveis SET id = id - 1 WHERE id > ?''', (id,))
    conexao.commit()
    cursor.close()
    conexao.close()

# Função para imprimir todos os id no banco de dados


def imprimir_banco_dados():
    for row in consultar_todos_id_banco_dados():
        print(row)

# Função para obter o numero do último ID


def obter_numero_do_ultimo_id():
    conexao = conectar_banco_dados()
    cursor = cursor_banco_dados(conexao)
    cursor.execute('SELECT MAX(id) FROM variaveis')
    ultimo_id = cursor.fetchone()[0]
    cursor.close()
    conexao.close()
    return ultimo_id


# criar_banco_dados()
#inserir_banco_dados(20, 22, 25.2, 22.8, 10.1, 9.8, 9.9, 10.2, 3.5, 4.0, 3.8, 22, 22, 22, 22, 'OI')
# atualizar_banco_dados(1, 10, 62, 25.2, 22.8, 10.1, 9.8, 9.9, 10.2, 3.5, 4.0, 3.8)
# deletar_banco_dados(1)
# imprimir_banco_dados()
# print(obter_numero_do_ultimo_id())
